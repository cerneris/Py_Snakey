import pygame
import random

def generate_food():
    x_rand = random.randrange(0, 790, 10)
    y_rand = random.randrange(0, 590, 10)
    return x_rand, y_rand

def game_not_over(snake, window):
    if snake[0] >= window[0] - 10:
        return False
    if snake[0] <= 0:
        return False
    if snake[1] >= window[1] - 10:
        return False
    if snake[1] <= 0:
        return False
    return True

def main():
    white = (255, 255, 255)
    green = (0, 255, 0)
    game = pygame
    game.init()
    window_size = (800, 600)
    window = game.display.set_mode(window_size)
    game.display.set_caption("Snakey game")
    x = 400
    y = 300
    w = 10
    h = 10
    vel = 10
    hit = False
    food_x, food_y = generate_food()
    food = [food_x, food_y, w, h]
    head = [x, y, w, h]
    snakey = [head]
    key_pressed = {"up" : True, "down" : False, "left" : False, "right" : False}
    current_way = "up"
    old_way = "up"
    game_is_not_over = True
    points = 0
    while game_is_not_over:
        value = 0
        for event in game.event.get():
            if event.type == game.KEYDOWN:
                print("Key pressed")
                print(event.key)
                if event.key == game.K_UP:
                    if key_pressed["down"] == True:
                        pass
                    else:
                        for keys in key_pressed:
                            key_pressed[keys] = False
                        key_pressed["up"] = True
                        break
                if event.key == game.K_DOWN:
                    if key_pressed["up"] == True:
                        pass
                    else:
                        for keys in key_pressed:
                            key_pressed[keys] = False
                        key_pressed["down"] = True
                        break
                if event.key == game.K_LEFT:
                    if key_pressed["right"] == True:
                        pass
                    else:
                        for keys in key_pressed:
                            key_pressed[keys] = False
                        key_pressed["left"] = True
                        break
                if event.key == game.K_RIGHT:
                    if key_pressed["left"] == True:
                        pass
                    else:
                        for keys in key_pressed:
                            key_pressed[keys] = False
                        key_pressed["right"] = True
                        break
        if key_pressed["up"]:
            if y > 0:
                y -= vel
            else:
                y = 0
        if key_pressed["down"]:
            if y < 600 - h - vel:
                y += vel
            else:
                y = 600 - h
        if key_pressed["left"]:
            if x > 0:
                x -= vel
            else:
                x = 0
        if key_pressed["right"]:
            if x < 800 - w - vel:
                x += vel
            else:
                x = 800 - w
        game.time.delay(100)
        window.fill(white)
        new_head = [x, y, w, h]
        snakey.pop()
        snakey.insert(0, new_head)
        for tails in snakey:
            game.draw.rect(window, 0, tails)
        if hit != True:
            game.draw.rect(window, 0, food)
        else:
            points += 1
            food_x, food_y = generate_food()
            food = [food_x, food_y, w, h]
            snakey.insert(len(snakey), _tail)
            print(snakey)
            hit = False
        if snakey[0] == food:
            if len(snakey) == 1:
                _tail = snakey[0]
            else:
                _tail = snakey[len(snakey) - 1]
                print(_tail)
            hit = True
            print("HIT")
        game.display.update()
        game_is_not_over = game_not_over(new_head, window_size)
    window.fill(white)
    font = game.font.Font('freesansbold.ttf', 32)
    text = font.render("Points: {}".format(int(points)), True, green, white)
    rect = text.get_rect(center=(400,300))
    window.blit(text, rect)
    game.display.update()
    while True:
        for event in game.event.get():
            if event.type == game.KEYDOWN:
                game.quit()
                break
if __name__ == '__main__':
    main()
